# fabric > 2025-06-09 11:01pm
https://universe.roboflow.com/semester4/fabric-qxgmo-qeviu

Provided by a Roboflow user
License: CC BY 4.0

